import pandas as pd
from src.logger import informer
from src.pipeline.predict_pipeline import Prediction


class BostonHousingCLI:
    """CLI Interface for the Boston Housing Price Prediction system.

    Handles input collection, validation, and user presentation.
    """

    FEATURE_CONFIG = {
        "crim": {"desc": "Per capita crime rate", "min": 0.0, "max": 90.0},
        "zn": {"desc": "Zoned residential land (%)", "min": 0.0, "max": 100.0},
        "indus": {"desc": "Non-retail business acres (%)", "min": 0.0, "max": 30.0},
        "chas": {
            "desc": "Charles River dummy (0 = No, 1 = Yes)",
            "min": 0,
            "max": 1,
        },
        "nox": {
            "desc": "Nitric oxide concentration (ppm)",
            "min": 0.3,
            "max": 0.9,
        },
        "rm": {"desc": "Average number of rooms per dwelling", "min": 1.0, "max": 10.0},
        "age": {"desc": "Units built prior to 1940 (%)", "min": 0.0, "max": 100.0},
        "dis": {
            "desc": "Weighted distance to employment centers",
            "min": 1.0,
            "max": 15.0,
        },
        "rad": {
            "desc": "Accessibility index to radial highways",
            "min": 1,
            "max": 24,
        },
        "tax": {
            "desc": "Full-value property-tax rate ($ per $10k)",
            "min": 150,
            "max": 800,
        },
        "ptratio": {"desc": "Pupil-teacher ratio", "min": 10.0, "max": 25.0},
        "black": {
            "desc": "Proportion of Black residents factor",
            "min": 0.0,
            "max": 400.0,
        },
        "lstat": {"desc": "Lower status population (%)", "min": 1.0, "max": 40.0},
    }

    def __init__(self):
        self.predict_pipeline = Prediction()

    def _display_header(self) -> None:
        """Private helper to print CLI welcome header."""
        print("\n" + "=" * 50)
        print("     BOSTON HOUSING PRICE PREDICTION SYSTEM")
        print("=" * 50)
        print("Please enter feature values as prompted below:\n")

    def _get_feature_input(self, feature: str, info: dict) -> float:
        """Private helper to collect and validate a single numeric input."""
        while True:
            try:
                prompt_msg = f"-> {feature.upper()} ({info['desc']}) [{info['min']} - {info['max']}]: "
                val_str = input(prompt_msg).strip()
                val = float(val_str)

                if val < info["min"] or val > info["max"]:
                    print(
                        f"   ⚠️  Notice: Value {val} is outside standard dataset range [{info['min']} - {info['max']}]."
                    )

                return val
            except ValueError:
                print(
                    "   ❌ Invalid entry! Please enter a valid numerical number."
                )

    def collect_features(self) -> pd.DataFrame:
        """Collects all feature inputs and packages them into a 1-row DataFrame."""
        user_data = {}
        for feature, info in self.FEATURE_CONFIG.items():
            user_data[feature] = self._get_feature_input(feature, info)

        return pd.DataFrame([user_data])

    def _display_prediction(self, predicted_val: float) -> None:
        """Private helper to format and output prediction results."""
        print("\n" + "=" * 50)
        print(f"🏠 Predicted Median House Price: ${predicted_val * 1000:,.2f}")
        print(f"   (Raw Model Output: {predicted_val:.4f})")
        print("=" * 50 + "\n")

    def run(self) -> None:
        """Orchestrates the application flow."""
        try:
            informer.info("CLI Application started.")
            self._display_header()

            # 1. Collect inputs & format into DataFrame
            input_df = self.collect_features()
            informer.info(f"Inputs converted to DataFrame shape: {input_df.shape}")

            # 2. Trigger Prediction Pipeline method
            predicted_val = self.predict_pipeline.make_prediction_from_list(
                input_df
            )

            # 3. Present Output
            self._display_prediction(predicted_val)
            informer.info(
                f"Prediction completed successfully: {predicted_val:.4f}"
            )

        except Exception as err:
            print(f"\n❌ Execution failed: {err}")
            informer.error(f"Error inside BostonHousingCLI execution: {err}")


if __name__ == "__main__":
    app = BostonHousingCLI()
    app.run()