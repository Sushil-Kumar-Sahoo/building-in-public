# Boston Housing Price Prediction - End-to-End ML Pipeline

A production-grade, modular Machine Learning project for predicting house prices using the Boston Housing dataset. Built using clean software engineering principles, robust configuration handling, custom logging, and decoupled pipeline stages.

## 📸 Output Preview

![CLI Output](output.png)

---

## 📌 Features

* **Modular Architecture**: Decoupled components for data ingestion, data transformation, model training, and prediction pipelines.
* **Config-Driven**: Centralized management of paths, parameters, and hyperparameters using YAML configuration (`config/config.yaml`).
* **Robust Preprocessing**: Standardized data transformation pipeline using `Scikit-Learn` saved as reusable pickle artifacts (`preprocessor.pkl`).
* **Custom Logging**: Custom execution logging for real-time tracking and easy debugging.

---

## 📁 Repository Structure

```text
boston_housing/
├── config/
│   └── config.yaml          # Pipeline configurations and parameters
├── data/
│   ├── raw/                 # Raw split datasets (train.csv, test.csv)
│   └── processed/           # Transformed datasets (optional storage)
├── models/                  # Saved artifacts (preprocessor.pkl, model.pkl)
├── src/
│   ├── components/
│   │   ├── __init__.py
│   │   ├── data_ingestion.py      # Reads data, splits into train/test
│   │   ├── data_transformation.py # Handles scaling & missing values
│   │   └── model_trainer.py       # Model training & evaluation
│   ├── pipeline/
│   │   ├── __init__.py
│   │   ├── train_pipeline.py     # Orchestrates full training workflow
│   │   └── predict_pipeline.py   # Handles inference on new data
│   ├── __init__.py
│   ├── logger.py                 # Custom logging module
│   └── utils.py                  # Helper functions (YAML reader, pickle saver)
├── app.py                        # Interactive CLI prediction interface
├── setup.py                      # Package installation setup
└── README.md
```

---

## ⚙️ Installation

1. Make sure you have an active Python virtual environment (e.g., `conda` or `venv`).
2. Install all required libraries and the local package by running:

```bash
python -m pip install -r requirements.txt
```

The `setup.py` file is used to install this project as a local Python package so its modules can be imported anywhere. You can manually run it by executing `pip install -e .` to install the package in editable mode.

---

## 🚀 Usage

Run the interactive CLI application to predict Boston housing prices by executing:

```bash
python app.py
```

The CLI will prompt you to enter values for all 13 features (e.g., crime rate, average number of rooms, property-tax rate) and then display the predicted median house price.
