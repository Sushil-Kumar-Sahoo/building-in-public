import datetime
now = datetime.datetime.now()

class Logger:
    def info(self, status: str):
        print(f"[{now.strftime('%Y-%m-%d %H:%M:%S')}]: {status}")


    def error(self, status: str):
        print(f"[ERROR]: {status}")

# Create an instance so you can import it directly
informer = Logger()

if __name__=='__main__':
    informer.info("Logger file working successfully")
