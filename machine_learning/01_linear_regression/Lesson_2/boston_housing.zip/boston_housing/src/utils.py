from src.logger import informer
import pickle
import yaml
import os

# Safely read and parse the configuration file
def read_yaml(config_path: str = "config/config.yaml") -> dict:
    with open(config_path, "r") as file:
        try:
            data = yaml.safe_load(file)
            return data  # <--- CRITICAL: Must return the loaded dictionary!
        except yaml.YAMLError as error:
            print(f"Error parsing file: {error}")
            return {}

def save_object(file_path,df_obj):
    try:
        dir_name = os.path.dir_name(file_path)
        if dir_name:
            os.makedirs(dir_name,exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as f:
            df_obj.to_csv(f, index=False)
    except Exception as err:
        try:
            informer.info(f"Error occur during saving {df_obj.name}")
        except Exception as err:
            informer.info(f"Error !!! happend during saving  a df_object : name unknown")

def save_artifacts(model_obj,file_path):
    try:
        dir_path = os.path.dirname(file_path)
        if dir_path:
            os.makedirs(dir_path, exist_ok=True)            
        with open(file_path, 'wb') as file:
            pickle.dump(model_obj, file)
        informer.info(f"Artifacts in {file_path} is saved")
    except Exception as err:
        informer.info("Error occur duirng saving artifacts")
        raise err

def load_pkl_file(file_path):
    try:
        with open(file_path, 'rb') as file:
            obj = pickle.load(file)
        informer.info(f"Successfully loaded artifact from: {file_path}")
        return obj
    except Exception as err:
        raise err

if __name__ == "__main__":
    config_data = read_yaml("config/config.yaml")
    informer.info("Utils.py file worked successfully")