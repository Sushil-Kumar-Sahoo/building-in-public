import os
import numpy as np
import pandas as pd
from dataclasses import dataclass
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler,OneHotEncoder
from src.utils import read_yaml
from src.logger import informer



@dataclass
class DataTransformationConfig:
    preprocessor_obj_file_path: str = os.path.join("artifacts", "preprocessor.pkl")

class DataTransformation:
    def __init__(self, config_path: str = "config/config.yaml"):
        self.transformation_config = DataTransformationConfig()
        self.config = read_yaml(config_path)

    def get_data_transformer_object(self, numerical_columns: list,categorical_columns: list) -> ColumnTransformer:
        """
        Creates and returns the Scikit-Learn preprocessing pipeline.
        """
        numeric_transformers = StandardScaler()
        categorical_transformers = OneHotEncoder(handle_unknown='ignore',drop='first')
        try:
            preprocessor = ColumnTransformer(
            transformers=[ ('num',numeric_transformers,numerical_columns),
                           ('cat',categorical_transformers,categorical_columns) ],
                           remainder='passthrough')

            return preprocessor

        except Exception as e:
            informer.error(f"Error in creating transformer object: {str(e)}")
            raise e

    def initiate_data_transformation(self, train_path: str, test_path: str):
        try:
            informer.info("Data Transformation process started.")

            train_df = pd.read_csv(train_path)
            test_df = pd.read_csv(test_path)

            target_column = self.config["data"]["target_column"]
            remove_column = self.config["data"]["remove_column"] # Id and other unnecessary needs to be removed


            
            # Separate features and target
            input_feature_train_df = train_df.drop(columns=[target_column,remove_column], axis=1)  # X_train
            target_feature_train_df = train_df[target_column]                                       # Y_train

            input_feature_test_df = test_df.drop(columns=[target_column,remove_column], axis=1)  # X_test
            target_feature_test_df = test_df[target_column]                                      # Y_test

            # Get numerical column names
            numerical_columns = self.config["data"]["numerical_columns"]
            # Get categorical columns
            categorical_columns = self.config["data"]["categorical_columns"]


            informer.info("Obtaining preprocessing pipeline object...")
            preprocessing_obj = self.get_data_transformer_object(numerical_columns,categorical_columns)


            # Fit on training features and transform both train and test
            informer.info("Applying preprocessor on training and testing datasets...")
            input_feature_train_arr = preprocessing_obj.fit_transform(input_feature_train_df)
            input_feature_test_arr = preprocessing_obj.transform(input_feature_test_df)  
            

            # Combine transformed features with target into single numpy arrays
            train_arr = np.c_[input_feature_train_arr, np.array(target_feature_train_df)]
            test_arr = np.c_[input_feature_test_arr, np.array(target_feature_test_df)]

            preprocessor_obj_file_path = self.config["artifacts"]["preprocessor_path"]
            
            return (train_arr,test_arr,preprocessing_obj,preprocessor_obj_file_path)
        
        except Exception as err:
            informer.info(f"Error In Data Transformation {err}")
            raise err
        



        #     # Save the fitted preprocessor object for model deployment/prediction
            # save_object(
            #     file_path=self.transformation_config.preprocessor_obj_file_path,
            #     obj=preprocessing_obj
            # )
        
        #     informer.info(f"Preprocessor object saved at {self.transformation_config.preprocessor_obj_file_path}")

        #     return (
        #         train_arr,
        #         test_arr,
        #         self.transformation_config.preprocessor_obj_file_path
        #     )

        # except Exception as e:
        #     informer.error(f"Error occurred in Data Transformation: {str(e)}")
        #     raise e
if __name__ == '__main__':
    informer.info("Data Transformation file is working properly")