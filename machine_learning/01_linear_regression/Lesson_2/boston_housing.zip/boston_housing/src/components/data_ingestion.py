import os
import pandas as pd
from dataclasses import dataclass
from src.utils import read_yaml
from sklearn.model_selection import train_test_split
from src.logger import informer  # Assuming you have a informer setup

@dataclass
class DataIngestionConfig:
    raw_data_path: str = os.path.join("data", "raw", "data.csv")
    train_data_path: str = os.path.join("data", "raw", "train.csv")
    test_data_path: str = os.path.join("data", "raw", "test.csv")

class DataIngestion:
    def __init__(self, config_path: str = "config/config.yaml"):
        self.ingestion_config = DataIngestionConfig()
        self.config = read_yaml(config_path)

    def initiate_data_ingestion(self):
        informer.info("Data Ingestion process started.")
        try:
            # 1. Fetch raw dataset (e.g., from local folder, URL, or DB)
            # You can pull paths directly from config.yaml:
            source_path = self.config["data"]["train_path"] 
            df = pd.read_csv(source_path)
            informer.info(f"Successfully loaded raw dataset from {source_path}")

            # 2. Ensure directories exist
            os.makedirs(os.path.dirname(self.ingestion_config.train_data_path), exist_ok=True)

            # 3. Save raw baseline copy
            df.to_csv(self.ingestion_config.raw_data_path, index=False, header=True)

            # 4. Perform Train/Test Split
            informer.info("Initiating train test split...")
            train_set, test_set = train_test_split(
                df, 
                test_size=self.config["data"]["test_size"], 
                random_state=self.config["data"]["random_state"]
            )

            # 5. Save splits locally
            train_set.to_csv(self.ingestion_config.train_data_path, index=False, header=True)
            test_set.to_csv(self.ingestion_config.test_data_path, index=False, header=True)

            informer.info("Data Ingestion completed successfully.")

            # Return paths to be passed into Data Transformation step
            return (
                self.ingestion_config.train_data_path,
                self.ingestion_config.test_data_path
            )

        except Exception as e:
            informer.error(f"Error occurred during Data Ingestion: {str(e)}")
            raise e

if __name__ == "__main__":
    # Test script standalone
    obj = DataIngestion()
    train_path, test_path = obj.initiate_data_ingestion()
    print(f"Train Path: {train_path}\nTest Path: {test_path}")
    
