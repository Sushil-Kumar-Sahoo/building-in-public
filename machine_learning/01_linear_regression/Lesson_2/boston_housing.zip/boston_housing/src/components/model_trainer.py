from sklearn.linear_model import SGDRegressor
from sklearn.metrics import mean_squared_error
from src.logger import informer
from src.utils import read_yaml


class ModelTraining:
    def __init__(self,train_arr,test_arr,config_path = "config/config.yaml"):
        self.train_arr = train_arr
        self.test_arr = test_arr
        self.sgd_reg = SGDRegressor(max_iter=1000,eta0=0.01,random_state=42)
        self.config = read_yaml(config_path)

    def split_arr(self): 
        # train split
        x_train = self.train_arr[:, :-1]
        y_train = self.train_arr[:, -1]

        # test split 
        x_test = self.test_arr[:, :-1]
        y_test = self.test_arr[:, -1]

        return (x_train,y_train,x_test,y_test)

    def initiate_model_training(self):
        try :
            informer.info("Initiating model training")

            x_train, y_train, x_test, y_test = self.split_arr()

            self.sgd_reg.fit(x_train,y_train)

            y_test_predict = self.sgd_reg.predict(x_test)
            y_train_predict = self.sgd_reg.predict(x_train)

            # Evaluation metrics 
            mse_train = mean_squared_error(y_train,y_train_predict)
            informer.info(f"MSE (Train) : {mse_train}")
            mse_test = mean_squared_error(y_test,y_test_predict)
            informer.info(f"MSE (Test) : {mse_test}")

            informer.info("Model fitting and evaluation is now completed.")
            
            # return the fitted model obj and it's path to save artifacts
            model_path = self.config["artifacts"]["model_path"]
            return (self.sgd_reg,model_path)
        except Exception as err :
            informer.info("Error occur during model training")
            raise err

if __name__ == '__main__':
    informer.info("Model Training Complete")