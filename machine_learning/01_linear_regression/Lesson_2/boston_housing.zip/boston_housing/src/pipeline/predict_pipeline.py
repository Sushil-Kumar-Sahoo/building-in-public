import pandas as pd
from src.logger import informer
from src.utils import load_pkl_file, read_yaml


class Prediction:

    def __init__(self, config_path="config/config.yaml"):
        self.config = read_yaml(config_path)
        self.preprocessor_path = self.config["artifacts"]["preprocessor_path"]
        self.model_path = self.config["artifacts"]["model_path"]

    def make_prediction_from_list(self, feature: pd.DataFrame) -> float:
        try:
            preprocessing_obj = load_pkl_file(self.preprocessor_path)
            model_obj = load_pkl_file(self.model_path)

            processed_df = preprocessing_obj.transform(feature)
            prediction = model_obj.predict(processed_df)

            # Return raw float output
            return float(prediction[0])

        except Exception as err:
            informer.error("Error occurred during making prediction.")
            raise err