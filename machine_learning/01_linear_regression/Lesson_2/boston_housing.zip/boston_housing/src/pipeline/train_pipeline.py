from src.components.data_ingestion import DataIngestion
from src.components.data_transformation import DataTransformation,DataTransformationConfig
from src.utils import save_artifacts,save_object
from src.components.model_trainer import ModelTraining
import pandas as pd

def run_pipeline():
    # 1. Run Data Ingestion
    ingestion = DataIngestion()
    train_data_path, test_data_path = ingestion.initiate_data_ingestion()
    
    # 2. Pass Ingestion outputs directly into Data Transformation
    transformation = DataTransformation()
    train_arr, test_arr, preprocessing_obj, preprocessor_obj_file_path = transformation.initiate_data_transformation(
        train_path=train_data_path, 
        test_path=test_data_path
    )
    # saving the transformed arr
    # save_object()
    # save preprocessing obj as an artifact
    save_artifacts(preprocessing_obj,preprocessor_obj_file_path)

    #model training
    model_train_obj = ModelTraining(train_arr,test_arr)
    fitted_model,model_artifacts_path = model_train_obj.initiate_model_training()
    # save model artifacts for future use case
    save_artifacts(fitted_model,model_artifacts_path)


if __name__ == "__main__":
    run_pipeline()