"""Streamlit web interface for the Boston Housing Price Prediction system.

Refactored from the original CLI (BostonHousingCLI) into an interactive,
form-based web app. Input collection, validation, and presentation are now
handled through Streamlit widgets, but the underlying prediction contract
(the `Prediction` class and its `make_prediction_from_list` method) is
unchanged.
"""
import pandas as pd
import streamlit as st

from src.logger import informer
from src.pipeline.predict_pipeline import Prediction

HERO_IMAGE_URL = (
    "https://images.unsplash.com/photo-1768326530593-00a0b2627063"
    "?auto=format&fit=crop&w=1600&q=80"
)

# CSS uses a plain (non f-string) template + .replace() so the many literal
# `{ }` braces in the stylesheet don't have to be escaped for str.format/f-strings.
_THEME_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Public+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap');

:root {
    --ink: #1C2B33;
    --brick: #8A3D2E;
    --brick-light: #A2503D;
    --brass: #B4914F;
    --brass-light: #D8BD82;
    --parchment: #EFE7D8;
    --ledger: #2E3B32;
}

.stApp {
    background-color: var(--parchment);
    font-family: 'Public Sans', sans-serif;
}

.stApp *:focus-visible {
    outline: 2px solid var(--brass) !important;
    outline-offset: 2px;
}

.stApp h1, .stApp h2, .stApp h3, .stApp h4, .stApp h5, .stApp h6 {
    font-family: 'Fraunces', serif !important;
    color: var(--ink) !important;
}

/* NOTE: font-family is set once on .stApp above and inherited by ordinary
   text (p, li, label, span). Do NOT re-declare font-family directly on a
   bare `span` selector here — Streamlit renders its own icons (sidebar
   collapse arrow, expander chevron, etc.) as <span> elements holding a
   literal icon-font ligature name (e.g. "keyboard_double_arrow_right").
   A direct span{font-family:...} rule beats inheritance and swaps their
   icon font for ours, so the ligature name prints as raw text instead of
   rendering as a glyph. Inheritance leaves Streamlit's own icon rule
   (which targets those spans directly) free to win. */

[data-testid="stWidgetLabel"] p, [data-testid="stWidgetLabel"] label {
    color: var(--ink) !important;
    font-weight: 500 !important;
}

[data-testid="stColumn"] {
    border-color: var(--brass) !important;
    border-radius: 14px !important;
    padding: 1.15rem 1.25rem !important;
    background: rgba(255, 255, 255, 0.35);
}

[data-testid="stFormSubmitButton"] button {
    background: var(--brick) !important;
    color: var(--parchment) !important;
    border: 1px solid var(--brass) !important;
    border-radius: 10px !important;
    font-family: 'Public Sans', sans-serif !important;
    font-weight: 600 !important;
    letter-spacing: 0.02em;
    padding: 0.7rem 1.2rem !important;
    transition: transform 0.15s ease, box-shadow 0.15s ease;
}
[data-testid="stFormSubmitButton"] button:hover {
    background: var(--brick-light) !important;
    box-shadow: 0 10px 20px -10px rgba(138, 61, 46, 0.6);
    transform: translateY(-1px);
}

.hero-band {
    position: relative;
    border-radius: 22px;
    overflow: hidden;
    min-height: 320px;
    display: flex;
    align-items: flex-end;
    padding: 2.5rem;
    margin-bottom: 2rem;
    background-image:
        linear-gradient(180deg, rgba(28,43,51,0.30) 0%, rgba(28,43,51,0.55) 55%, rgba(20,32,38,0.92) 100%),
        url('__HERO_IMAGE_URL__');
    background-size: cover;
    background-position: center;
    box-shadow: 0 18px 40px -14px rgba(20,32,38,0.55);
}
.hero-plaque { max-width: 640px; }
.hero-plaque .hero-eyebrow {
    font-family: 'IBM Plex Mono', monospace;
    letter-spacing: 0.14em;
    font-size: 0.72rem;
    color: var(--brass-light);
    text-transform: uppercase;
    display: inline-block;
    margin-bottom: 0.6rem;
    border-bottom: 1px solid var(--brass);
    padding-bottom: 0.3rem;
}
.hero-plaque .hero-title {
    font-family: 'Fraunces', serif !important;
    font-size: clamp(1.9rem, 4vw, 3rem);
    font-weight: 600;
    margin: 0 0 0.5rem 0;
    line-height: 1.08;
    color: #F6F0E4 !important;
}
.hero-plaque .hero-tagline {
    font-family: 'Public Sans', sans-serif;
    font-size: 1.05rem;
    color: rgba(246, 240, 228, 0.88);
    margin: 0;
}
@media (prefers-reduced-motion: no-preference) {
    .hero-plaque { animation: heroRise 0.7s ease-out; }
}
@keyframes heroRise {
    from { opacity: 0; transform: translateY(14px); }
    to { opacity: 1; transform: translateY(0); }
}

.group-heading {
    font-family: 'Public Sans', sans-serif;
    font-weight: 700;
    font-size: 0.8rem;
    letter-spacing: 0.07em;
    text-transform: uppercase;
    color: var(--brick);
    border-bottom: 2px solid var(--brass);
    padding-bottom: 0.5rem;
    margin-bottom: 1rem;
}

.result-card {
    background: #F8F3E9;
    border: 2px solid var(--brass);
    border-radius: 18px;
    padding: 2.25rem 2rem 1.75rem 2rem;
    text-align: center;
    position: relative;
    box-shadow: 0 14px 32px -16px rgba(28,43,51,0.4);
    margin-top: 1.25rem;
}
.result-card .result-seal {
    position: absolute;
    top: -22px;
    left: 50%;
    transform: translateX(-50%);
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: var(--brass);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
    box-shadow: 0 6px 14px -6px rgba(28,43,51,0.45);
}
.result-card .result-eyebrow {
    font-family: 'IBM Plex Mono', monospace;
    text-transform: uppercase;
    letter-spacing: 0.12em;
    font-size: 0.75rem;
    color: var(--brick);
    margin: 0.9rem 0 0.25rem 0;
}
.result-card .result-value {
    font-family: 'Fraunces', serif !important;
    font-size: clamp(2.1rem, 5vw, 3.1rem);
    color: var(--brick) !important;
    margin: 0.15rem 0 0.9rem 0;
    font-weight: 700;
}
.result-card .result-divider {
    width: 64px;
    height: 2px;
    background: var(--brass);
    margin: 0 auto 0.9rem auto;
}
.result-card .result-raw {
    font-family: 'Public Sans', sans-serif;
    font-size: 0.85rem;
    color: var(--ledger);
    margin: 0;
}
.result-card .result-raw span {
    font-family: 'IBM Plex Mono', monospace;
    font-weight: 600;
}

@media (max-width: 640px) {
    .hero-band { padding: 1.5rem; min-height: 240px; }
}
</style>
"""


@st.cache_resource(show_spinner="Loading prediction pipeline…")
def load_prediction_pipeline() -> Prediction:
    """Instantiates the prediction pipeline once per app process (cached).

    Streamlit reruns the whole script on every interaction, so caching this
    avoids re-loading the underlying model on every submit.
    """
    informer.info("Initializing prediction pipeline...")
    return Prediction()


class BostonHousingApp:
    """Streamlit web interface for the Boston Housing Price Prediction system.

    Handles input collection, validation (via widget bounds), and
    presentation — the web counterpart of the original BostonHousingCLI.
    """

    FEATURE_CONFIG = {
        "crim": {"desc": "Per capita crime rate", "min": 0.0, "max": 90.0},
        "zn": {"desc": "Zoned residential land (%)", "min": 0.0, "max": 100.0},
        "indus": {"desc": "Non-retail business acres (%)", "min": 0.0, "max": 30.0},
        "chas": {
            "desc": "Charles River dummy (0 = No, 1 = Yes)",
            "min": 0,
            "max": 1,
        },
        "nox": {
            "desc": "Nitric oxide concentration (ppm)",
            "min": 0.3,
            "max": 0.9,
        },
        "rm": {"desc": "Average number of rooms per dwelling", "min": 1.0, "max": 10.0},
        "age": {"desc": "Units built prior to 1940 (%)", "min": 0.0, "max": 100.0},
        "dis": {
            "desc": "Weighted distance to employment centers",
            "min": 1.0,
            "max": 15.0,
        },
        "rad": {
            "desc": "Accessibility index to radial highways",
            "min": 1,
            "max": 24,
        },
        "tax": {
            "desc": "Full-value property-tax rate ($ per $10k)",
            "min": 150,
            "max": 800,
        },
        "ptratio": {"desc": "Pupil-teacher ratio", "min": 10.0, "max": 25.0},
        "black": {
            "desc": "Proportion of Black residents factor",
            "min": 0.0,
            "max": 400.0,
        },
        "lstat": {"desc": "Lower status population (%)", "min": 1.0, "max": 40.0},
    }

    # Purely presentational grouping, shared by both the 3-column input
    # layout and the sidebar Feature Reference Guide. Every FEATURE_CONFIG
    # key appears in exactly one group.
    FEATURE_GROUPS = {
        "📍 Location & Zoning": ["crim", "zn", "indus", "chas"],
        "🏗️ Structure & Access": ["nox", "rm", "age", "dis", "rad"],
        "💰 Economic & Social": ["tax", "ptratio", "black", "lstat"],
    }

    # Beginner-friendly, plain-English explanations for the sidebar glossary.
    # Deliberately separate from FEATURE_CONFIG["desc"], which stays short
    # for use as widget tooltip text.
    FEATURE_GLOSSARY = {
        "crim": "Per capita crime rate in the town (lower = safer neighborhood).",
        "zn": "Percentage of residential land zoned for large lots (>25,000 sq. ft.).",
        "indus": "Percentage of non-retail/industrial business acres per town.",
        "chas": "Charles River proximity (Yes = property borders the river, No = does not border).",
        "nox": "Air pollution level — nitric oxide concentration, in parts per million.",
        "rm": "Average number of rooms per dwelling.",
        "age": "Percentage of owner-occupied units built before 1940.",
        "dis": "Weighted distance to major Boston employment centers.",
        "rad": "Highway accessibility index (ease of commute to major routes).",
        "tax": "Property tax rate per $10,000 of value.",
        "ptratio": "Pupil-teacher ratio in local school districts (class-size indicator).",
        "black": "Demographic index: proportion of Black residents, by town.",
        "lstat": "Percentage of the population considered lower socio-economic status.",
    }

    def __init__(self) -> None:
        self.predict_pipeline = load_prediction_pipeline()

    def _inject_theme(self) -> None:
        """Private helper to inject the app's fonts, palette, and component CSS."""
        st.markdown(
            _THEME_CSS.replace("__HERO_IMAGE_URL__", HERO_IMAGE_URL),
            unsafe_allow_html=True,
        )

    def _render_sidebar(self) -> None:
        """Private helper to render sidebar context, the Feature Reference
        Guide, and dataset provenance notes. Built entirely from native
        st.sidebar-context calls — no raw HTML/custom CSS lives here, so it
        can't collide with Streamlit's own sidebar chrome (collapse arrow,
        expander chevrons, etc.)."""
        with st.sidebar:
            st.header("🏛️ About This Instrument")
            st.caption(
                "Built on the classic Boston Housing dataset "
                "(Harrison & Rubinfeld, 1978), served through your "
                "existing prediction pipeline."
            )

            st.divider()
            st.subheader("📖 Feature Reference Guide")
            st.caption("Plain-English meaning of each of the 13 inputs.")

            for group_label, feature_names in self.FEATURE_GROUPS.items():
                with st.expander(group_label):
                    for feature in feature_names:
                        st.markdown(
                            f"**{feature.upper()}** — {self.FEATURE_GLOSSARY[feature]}"
                        )

            st.divider()
            with st.expander("⚠️ Dataset note"):
                st.markdown(
                    "One input, `BLACK`, encodes neighborhood racial "
                    "composition as a numeric predictor. This is the "
                    "documented reason scikit-learn removed this dataset "
                    "from `load_boston` in version 1.2. It's kept here "
                    "only so the schema matches your existing pipeline "
                    "exactly — worth reconsidering before any real-world use."
                )

            st.divider()
            st.caption("Skyline photograph via Unsplash.")

    def _display_header(self) -> None:
        """Private helper to render the hero banner (web counterpart of the CLI header)."""
        st.markdown(
            """
            <div class="hero-band">
                <div class="hero-plaque">
                    <span class="hero-eyebrow">Est. Valuation Instrument</span>
                    <h1 class="hero-title">The Beacon Housing Appraisal</h1>
                    <p class="hero-tagline">Thirteen neighborhood signals. One considered estimate.</p>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    @staticmethod
    def _resolve_step(min_val: float, max_val: float) -> float:
        """Chooses a sensible +/- increment for a feature's range."""
        span = max_val - min_val
        if span <= 1:
            return 0.01
        if span <= 15:
            return 0.1
        return 1.0

    def _get_feature_input(self, feature: str, info: dict) -> float:
        """Private helper to render a single widget for one feature and return its value.

        Binary flags (min=0, max=1) render as a Yes/No selectbox; every other
        feature renders as a bounded number_input using FEATURE_CONFIG's
        min/max as hard widget bounds (the ranges the CLI previously only
        warned about are now enforced directly by the widget).
        """
        is_binary_flag = info["min"] == 0 and info["max"] == 1
        if is_binary_flag:
            choice = st.selectbox(
                feature.upper(),
                options=["No", "Yes"],
                help=info["desc"],
                key=f"input_{feature}",
            )
            return 1.0 if choice == "Yes" else 0.0

        step = self._resolve_step(info["min"], info["max"])
        default_value = round((info["min"] + info["max"]) / 2, 2)
        return st.number_input(
            feature.upper(),
            min_value=float(info["min"]),
            max_value=float(info["max"]),
            value=float(default_value),
            step=step,
            help=info["desc"],
            key=f"input_{feature}",
            format="%.2f",
        )

    def collect_features(self) -> pd.DataFrame:
        """Renders all feature widgets in a 3-column layout and packages
        them into a 1-row DataFrame with columns in FEATURE_CONFIG order."""
        user_data: dict = {}
        columns = st.columns(len(self.FEATURE_GROUPS), gap="medium", border=True)
        for column, (group_label, feature_names) in zip(columns, self.FEATURE_GROUPS.items()):
            with column:
                st.markdown(f'<p class="group-heading">{group_label}</p>', unsafe_allow_html=True)
                for feature in feature_names:
                    info = self.FEATURE_CONFIG[feature]
                    user_data[feature] = self._get_feature_input(feature, info)

        # Re-order to the exact column order the pipeline expects, regardless
        # of the presentational grouping above.
        ordered_data = {feature: user_data[feature] for feature in self.FEATURE_CONFIG}
        return pd.DataFrame([ordered_data])

    def _display_prediction(self, predicted_val: float) -> None:
        """Private helper to format and render the prediction as an appraisal-style card."""
        formatted_price = f"${predicted_val * 1000:,.2f}"
        st.markdown(
            f"""
            <div class="result-card">
                <div class="result-seal">🏠</div>
                <p class="result-eyebrow">Appraised Estimate</p>
                <h2 class="result-value">{formatted_price}</h2>
                <div class="result-divider"></div>
                <p class="result-raw">Raw model output — <span>{predicted_val:.4f}</span></p>
            </div>
            """,
            unsafe_allow_html=True,
        )

    def _run_prediction(self, input_df: pd.DataFrame) -> None:
        """Private helper that calls the prediction pipeline and renders the outcome."""
        try:
            informer.info(f"Inputs converted to DataFrame shape: {input_df.shape}")
            predicted_val = self.predict_pipeline.make_prediction_from_list(input_df)
            self._display_prediction(predicted_val)
            informer.info(f"Prediction completed successfully: {predicted_val:.4f}")
        except Exception as err:
            st.error(f"❌ Execution failed: {err}")
            informer.error(f"Error inside BostonHousingApp execution: {err}")

    def run(self) -> None:
        """Orchestrates the full Streamlit application flow."""
        if "app_started_logged" not in st.session_state:
            informer.info("Streamlit application started.")
            st.session_state.app_started_logged = True

        self._inject_theme()
        self._render_sidebar()
        self._display_header()

        st.markdown("#### Enter the Property's Neighborhood Characteristics")
        with st.form("feature_input_form"):
            input_df = self.collect_features()
            submitted = st.form_submit_button(
                "🔮 Appraise This Property",
                use_container_width=True,
                type="primary",
            )

        if submitted:
            self._run_prediction(input_df)


def main() -> None:
    st.set_page_config(
        page_title="Boston Housing Price Prediction",
        page_icon="🏠",
        layout="wide",
        initial_sidebar_state="expanded",
    )
    app = BostonHousingApp()
    app.run()


if __name__ == "__main__":
    main()