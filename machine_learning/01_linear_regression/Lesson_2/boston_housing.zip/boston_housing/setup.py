from setuptools import find_packages, setup
from typing import List

HYPEN_E_DOT = '-e .'

def get_requirements(file_path: str) -> List[str]:
    '''
    This function returns the list of requirements from a given file.
    '''
    requirements = []
    try:
        with open(file_path) as file_obj:
            requirements = file_obj.readlines()
            requirements = [req.replace("\n", "") for req in requirements]

            if HYPEN_E_DOT in requirements:
                requirements.remove(HYPEN_E_DOT)
    except FileNotFoundError:
        pass
    
    return requirements

setup(
    name='boston_housing',
    version='0.0.1',
    author='Sushil Kumar Sahoo',
    author_email='',
    packages=find_packages(),
    install_requires=get_requirements('requirements.txt')
)
